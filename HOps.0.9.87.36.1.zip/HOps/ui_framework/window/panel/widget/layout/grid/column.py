

class Column():

    def __init__(self):

        self.width_percent = 0
        self.cells = []