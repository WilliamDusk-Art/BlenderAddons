import bpy

'''Replace node group nodes with radial array setup'''
def radial_array_nodes(node_group):
    radial_array = node_group
    radial_array.nodes.clear()

    Bounding_Box = radial_array.nodes.new("GeometryNodeBoundBox")
    Bounding_Box.location = [-1908, 496]
    Bounding_Box.name = "Bounding Box"
    #Node properties
    #unlinked node I/O

    Math = radial_array.nodes.new("ShaderNodeMath")
    Math.location = [670, -31]
    Math.name = "Math"
    #Node properties
    Math.operation = "MULTIPLY"
    Math.use_clamp = False
    #unlinked node I/O
    Math.inputs[2].default_value = 0.5

    Math_004 = radial_array.nodes.new("ShaderNodeMath")
    Math_004.location = [-284, -461]
    Math_004.name = "Math.004"
    #Node properties
    Math_004.operation = "ADD"
    Math_004.use_clamp = False
    #unlinked node I/O
    Math_004.inputs[1].default_value = -1.0
    Math_004.inputs[2].default_value = 0.5

    Switch_001 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_001.location = [997, 635]
    Switch_001.name = "Switch.001"
    #Node properties
    Switch_001.input_type = "VECTOR"
    #unlinked node I/O
    Switch_001.inputs[1].default_value = False
    Switch_001.inputs[2].default_value = 0.0
    Switch_001.inputs[3].default_value = 0.0
    Switch_001.inputs[4].default_value = 0
    Switch_001.inputs[5].default_value = 0
    Switch_001.inputs[6].default_value = False
    Switch_001.inputs[7].default_value = True
    Switch_001.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_001.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_001.inputs[12].default_value = ""
    Switch_001.inputs[13].default_value = ""
    Switch_001.inputs[16].default_value = None
    Switch_001.inputs[17].default_value = None
    Switch_001.inputs[18].default_value = None
    Switch_001.inputs[19].default_value = None
    Switch_001.inputs[20].default_value = None
    Switch_001.inputs[21].default_value = None
    Switch_001.inputs[22].default_value = None
    Switch_001.inputs[23].default_value = None
    Switch_001.inputs[24].default_value = None
    Switch_001.inputs[25].default_value = None

    Switch = radial_array.nodes.new("GeometryNodeSwitch")
    Switch.location = [-805, -194]
    Switch.name = "Switch"
    Switch.label = "Scale Correction"
    #Node properties
    Switch.input_type = "VECTOR"
    #unlinked node I/O
    Switch.inputs[1].default_value = False
    Switch.inputs[2].default_value = 0.0
    Switch.inputs[3].default_value = 0.0
    Switch.inputs[4].default_value = 0
    Switch.inputs[5].default_value = 0
    Switch.inputs[6].default_value = False
    Switch.inputs[7].default_value = True
    Switch.inputs[8].default_value = (1.0, 1.0, 1.0)
    Switch.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch.inputs[12].default_value = ""
    Switch.inputs[13].default_value = ""
    Switch.inputs[16].default_value = None
    Switch.inputs[17].default_value = None
    Switch.inputs[18].default_value = None
    Switch.inputs[19].default_value = None
    Switch.inputs[20].default_value = None
    Switch.inputs[21].default_value = None
    Switch.inputs[22].default_value = None
    Switch.inputs[23].default_value = None
    Switch.inputs[24].default_value = None
    Switch.inputs[25].default_value = None

    Vector_Math_013 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_013.location = [-632, 1186]
    Vector_Math_013.name = "Vector Math.013"
    #Node properties
    Vector_Math_013.operation = "SUBTRACT"
    #unlinked node I/O
    Vector_Math_013.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_013.inputs[3].default_value = 1.0

    Switch_006 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_006.location = [-342, 1364]
    Switch_006.name = "Switch.006"
    Switch_006.label = "T: Center relative to pivot , F: Center Pivot"
    #Node properties
    Switch_006.input_type = "VECTOR"
    #unlinked node I/O
    Switch_006.inputs[1].default_value = False
    Switch_006.inputs[2].default_value = 0.0
    Switch_006.inputs[3].default_value = 0.0
    Switch_006.inputs[4].default_value = 0
    Switch_006.inputs[5].default_value = 0
    Switch_006.inputs[6].default_value = False
    Switch_006.inputs[7].default_value = True
    Switch_006.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_006.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_006.inputs[12].default_value = ""
    Switch_006.inputs[13].default_value = ""
    Switch_006.inputs[16].default_value = None
    Switch_006.inputs[17].default_value = None
    Switch_006.inputs[18].default_value = None
    Switch_006.inputs[19].default_value = None
    Switch_006.inputs[20].default_value = None
    Switch_006.inputs[21].default_value = None
    Switch_006.inputs[22].default_value = None
    Switch_006.inputs[23].default_value = None
    Switch_006.inputs[24].default_value = None
    Switch_006.inputs[25].default_value = None

    Vector_Math_011 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_011.location = [-2266, 108]
    Vector_Math_011.name = "Vector Math.011"
    #Node properties
    Vector_Math_011.operation = "NORMALIZE"
    #unlinked node I/O
    Vector_Math_011.inputs[1].default_value = (0.0, 0.0, 0.0)
    Vector_Math_011.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_011.inputs[3].default_value = 1.0

    Group_Input = radial_array.nodes.new("NodeGroupInput")
    Group_Input.location = [-2703, -41]
    Group_Input.name = "Group Input"
    #Node properties
    radial_array.inputs.clear()
    radial_array.inputs.new("NodeSocketGeometry", "Geometry")
    radial_array.inputs.new("NodeSocketInt", "Count")
    radial_array.inputs.new("NodeSocketVector", "Axis")
    radial_array.inputs.new("NodeSocketFloat", "Rotation")
    radial_array.inputs.new("NodeSocketFloat", "Offset")
    radial_array.inputs.new("NodeSocketBool", "Apply Scale")
    radial_array.inputs.new("NodeSocketBool", "Center Pivot")
    radial_array.inputs.new("NodeSocketBool", "Full Circle")
    radial_array.inputs.new("NodeSocketVector", "Pivot Offset")
    radial_array.inputs.new("NodeSocketVector", "Rotation Offset")
    radial_array.inputs.new("NodeSocketObject", "Self")

    Vector = radial_array.nodes.new("FunctionNodeInputVector")
    Vector.location = [-1077, -342]
    Vector.name = "Vector"
    #Node properties
    Vector.vector = (1.0, 0.0, 0.0)
    #unlinked node I/O

    Switch_004 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_004.location = [59, -469]
    Switch_004.name = "Switch.004"
    #Node properties
    Switch_004.input_type = "INT"
    #unlinked node I/O
    Switch_004.inputs[1].default_value = False
    Switch_004.inputs[2].default_value = 0.0
    Switch_004.inputs[3].default_value = 0.0
    Switch_004.inputs[6].default_value = False
    Switch_004.inputs[7].default_value = True
    Switch_004.inputs[8].default_value = (1.0, 1.0, 1.0)
    Switch_004.inputs[9].default_value = (0.0, 0.0, 0.0)
    Switch_004.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_004.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_004.inputs[12].default_value = ""
    Switch_004.inputs[13].default_value = ""
    Switch_004.inputs[16].default_value = None
    Switch_004.inputs[17].default_value = None
    Switch_004.inputs[18].default_value = None
    Switch_004.inputs[19].default_value = None
    Switch_004.inputs[20].default_value = None
    Switch_004.inputs[21].default_value = None
    Switch_004.inputs[22].default_value = None
    Switch_004.inputs[23].default_value = None
    Switch_004.inputs[24].default_value = None
    Switch_004.inputs[25].default_value = None

    Align_Euler_to_Vector = radial_array.nodes.new("FunctionNodeAlignEulerToVector")
    Align_Euler_to_Vector.location = [-974, -544]
    Align_Euler_to_Vector.name = "Align Euler to Vector"
    #Node properties
    Align_Euler_to_Vector.axis = "Z"
    Align_Euler_to_Vector.pivot_axis = "AUTO"
    #unlinked node I/O
    Align_Euler_to_Vector.inputs["Rotation"].default_value = (0.0, 0.0, 0.0)
    Align_Euler_to_Vector.inputs["Factor"].default_value = 1.0

    Vector_Math_012 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_012.location = [1503, 586]
    Vector_Math_012.name = "Vector Math.012"
    Vector_Math_012.label = "Pivot Offset"
    #Node properties
    Vector_Math_012.operation = "ADD"
    #unlinked node I/O
    Vector_Math_012.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_012.inputs[3].default_value = 1.0

    Switch_009 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_009.location = [-2004, -391]
    Switch_009.name = "Switch.009"
    #Node properties
    Switch_009.input_type = "VECTOR"
    #unlinked node I/O
    Switch_009.inputs[1].default_value = False
    Switch_009.inputs[2].default_value = 0.0
    Switch_009.inputs[3].default_value = 0.0
    Switch_009.inputs[4].default_value = 0
    Switch_009.inputs[5].default_value = 0
    Switch_009.inputs[6].default_value = False
    Switch_009.inputs[7].default_value = True
    Switch_009.inputs[9].default_value = (0.0, 0.0, 0.0)
    Switch_009.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_009.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_009.inputs[12].default_value = ""
    Switch_009.inputs[13].default_value = ""
    Switch_009.inputs[16].default_value = None
    Switch_009.inputs[17].default_value = None
    Switch_009.inputs[18].default_value = None
    Switch_009.inputs[19].default_value = None
    Switch_009.inputs[20].default_value = None
    Switch_009.inputs[21].default_value = None
    Switch_009.inputs[22].default_value = None
    Switch_009.inputs[23].default_value = None
    Switch_009.inputs[24].default_value = None
    Switch_009.inputs[25].default_value = None

    Object_Info = radial_array.nodes.new("GeometryNodeObjectInfo")
    Object_Info.location = [-2414, -650]
    Object_Info.name = "Object Info"
    Object_Info.label = "Self"
    #Node properties
    Object_Info.transform_space = "ORIGINAL"
    #unlinked node I/O
    Object_Info.inputs["As Instance"].default_value = False

    Rotate_Euler = radial_array.nodes.new("FunctionNodeRotateEuler")
    Rotate_Euler.location = [1702, 263]
    Rotate_Euler.name = "Rotate Euler"
    #Node properties
    Rotate_Euler.type = "AXIS_ANGLE"
    Rotate_Euler.space = "OBJECT"
    #unlinked node I/O
    Rotate_Euler.inputs["Rotation"].default_value = (0.0, 0.0, 0.0)
    Rotate_Euler.inputs["Rotate By"].default_value = (0.0, 0.0, 0.0)

    Vector_Math_002 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_002.location = [831, -188]
    Vector_Math_002.name = "Vector Math.002"
    #Node properties
    Vector_Math_002.operation = "DIVIDE"
    #unlinked node I/O
    Vector_Math_002.inputs[0].default_value = (1.0, 1.0, 1.0)
    Vector_Math_002.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_002.inputs[3].default_value = 1.0

    Vector_Rotate_001 = radial_array.nodes.new("ShaderNodeVectorRotate")
    Vector_Rotate_001.location = [-1279, 392]
    Vector_Rotate_001.name = "Vector Rotate.001"
    #Node properties
    Vector_Rotate_001.rotation_type = "EULER_XYZ"
    Vector_Rotate_001.invert = False
    #unlinked node I/O
    Vector_Rotate_001.inputs["Center"].default_value = (0.0, 0.0, 0.0)
    Vector_Rotate_001.inputs["Axis"].default_value = (0.0, 0.0, 1.0)
    Vector_Rotate_001.inputs["Angle"].default_value = 0.0

    Vector_Math_003 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_003.location = [-696, 828]
    Vector_Math_003.name = "Vector Math.003"
    #Node properties
    Vector_Math_003.operation = "MULTIPLY"
    #unlinked node I/O
    Vector_Math_003.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_003.inputs[3].default_value = 1.0

    Vector_Math_004 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_004.location = [758, 1155]
    Vector_Math_004.name = "Vector Math.004"
    #Node properties
    Vector_Math_004.operation = "DOT_PRODUCT"
    #unlinked node I/O
    Vector_Math_004.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_004.inputs[3].default_value = 1.0

    Math_002 = radial_array.nodes.new("ShaderNodeMath")
    Math_002.location = [-144, -38]
    Math_002.name = "Math.002"
    #Node properties
    Math_002.operation = "RADIANS"
    Math_002.use_clamp = False
    #unlinked node I/O
    Math_002.inputs[1].default_value = 3.1415927410125732
    Math_002.inputs[2].default_value = 0.5

    Math_001 = radial_array.nodes.new("ShaderNodeMath")
    Math_001.location = [153, -113]
    Math_001.name = "Math.001"
    #Node properties
    Math_001.operation = "DIVIDE"
    Math_001.use_clamp = False
    #unlinked node I/O
    Math_001.inputs[2].default_value = 0.5

    Translate_Instances = radial_array.nodes.new("GeometryNodeTranslateInstances")
    Translate_Instances.location = [2917, 607]
    Translate_Instances.name = "Translate Instances"
    #Node properties
    #unlinked node I/O
    Translate_Instances.inputs["Selection"].default_value = True
    Translate_Instances.inputs["Local Space"].default_value = False

    Rotate_Instances = radial_array.nodes.new("GeometryNodeRotateInstances")
    Rotate_Instances.location = [3220, 591]
    Rotate_Instances.name = "Rotate Instances"
    #Node properties
    #unlinked node I/O
    Rotate_Instances.inputs["Selection"].default_value = True
    Rotate_Instances.inputs["Local Space"].default_value = False

    Math_003 = radial_array.nodes.new("ShaderNodeMath")
    Math_003.location = [909, 1169]
    Math_003.name = "Math.003"
    #Node properties
    Math_003.operation = "MULTIPLY"
    Math_003.use_clamp = False
    #unlinked node I/O
    Math_003.inputs[1].default_value = -1.0
    Math_003.inputs[2].default_value = 0.5

    Group_Output = radial_array.nodes.new("NodeGroupOutput")
    Group_Output.location = [3976, 397]
    Group_Output.name = "Group Output"
    #Node properties
    radial_array.outputs.clear()
    radial_array.outputs.new("NodeSocketGeometry", "Geometry")

    Realize_Instances = radial_array.nodes.new("GeometryNodeRealizeInstances")
    Realize_Instances.location = [3764, 404]
    Realize_Instances.name = "Realize Instances"
    #Node properties
    #unlinked node I/O

    Scale_Instances = radial_array.nodes.new("GeometryNodeScaleInstances")
    Scale_Instances.location = [3486, 518]
    Scale_Instances.name = "Scale Instances"
    #Node properties
    #unlinked node I/O
    Scale_Instances.inputs["Selection"].default_value = True
    Scale_Instances.inputs["Center"].default_value = (0.0, 0.0, 0.0)
    Scale_Instances.inputs["Local Space"].default_value = False

    Geometry_to_Instance = radial_array.nodes.new("GeometryNodeGeometryToInstance")
    Geometry_to_Instance.location = [-434, 240]
    Geometry_to_Instance.name = "Geometry to Instance"
    #Node properties
    #unlinked node I/O

    Scale_Instances_001 = radial_array.nodes.new("GeometryNodeScaleInstances")
    Scale_Instances_001.location = [-31, 241]
    Scale_Instances_001.name = "Scale Instances.001"
    #Node properties
    #unlinked node I/O
    Scale_Instances_001.inputs["Selection"].default_value = True
    Scale_Instances_001.inputs["Center"].default_value = (0.0, 0.0, 0.0)
    Scale_Instances_001.inputs["Local Space"].default_value = False

    Duplicate_Elements = radial_array.nodes.new("GeometryNodeDuplicateElements")
    Duplicate_Elements.location = [435, 208]
    Duplicate_Elements.name = "Duplicate Elements"
    #Node properties
    Duplicate_Elements.domain = "INSTANCE"
    #unlinked node I/O
    Duplicate_Elements.inputs["Selection"].default_value = True

    Vector_Rotate = radial_array.nodes.new("ShaderNodeVectorRotate")
    Vector_Rotate.location = [-570, -368]
    Vector_Rotate.name = "Vector Rotate"
    #Node properties
    Vector_Rotate.rotation_type = "EULER_XYZ"
    Vector_Rotate.invert = False
    #unlinked node I/O
    Vector_Rotate.inputs["Center"].default_value = (0.0, 0.0, 0.0)
    Vector_Rotate.inputs["Axis"].default_value = (0.0, 0.0, 1.0)
    Vector_Rotate.inputs["Angle"].default_value = 0.0

    Vector_Math_005 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_005.location = [-224, -319]
    Vector_Math_005.name = "Vector Math.005"
    #Node properties
    Vector_Math_005.operation = "SCALE"
    #unlinked node I/O
    Vector_Math_005.inputs[1].default_value = (0.0, 0.0, 0.0)
    Vector_Math_005.inputs[2].default_value = (0.0, 0.0, 0.0)

    Vector_Math_007 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_007.location = [1150, 1115]
    Vector_Math_007.name = "Vector Math.007"
    #Node properties
    Vector_Math_007.operation = "SCALE"
    #unlinked node I/O
    Vector_Math_007.inputs[1].default_value = (2.0, 2.0, 2.0)
    Vector_Math_007.inputs[2].default_value = (0.0, 0.0, 0.0)

    Vector_Math_009 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_009.location = [2307, 993]
    Vector_Math_009.name = "Vector Math.009"
    #Node properties
    Vector_Math_009.operation = "SCALE"
    #unlinked node I/O
    Vector_Math_009.inputs[1].default_value = (2.0, 2.0, 2.0)
    Vector_Math_009.inputs[2].default_value = (0.0, 0.0, 0.0)

    Switch_003 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_003.location = [2875, 890]
    Switch_003.name = "Switch.003"
    Switch_003.label = "Center pivot Fallback"
    #Node properties
    Switch_003.input_type = "VECTOR"
    #unlinked node I/O
    Switch_003.inputs[1].default_value = False
    Switch_003.inputs[2].default_value = 0.0
    Switch_003.inputs[3].default_value = 0.0
    Switch_003.inputs[4].default_value = 0
    Switch_003.inputs[5].default_value = 0
    Switch_003.inputs[6].default_value = False
    Switch_003.inputs[7].default_value = True
    Switch_003.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_003.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_003.inputs[12].default_value = ""
    Switch_003.inputs[13].default_value = ""
    Switch_003.inputs[16].default_value = None
    Switch_003.inputs[17].default_value = None
    Switch_003.inputs[18].default_value = None
    Switch_003.inputs[19].default_value = None
    Switch_003.inputs[20].default_value = None
    Switch_003.inputs[21].default_value = None
    Switch_003.inputs[22].default_value = None
    Switch_003.inputs[23].default_value = None
    Switch_003.inputs[24].default_value = None
    Switch_003.inputs[25].default_value = None

    Switch_002 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_002.location = [2594, 939]
    Switch_002.name = "Switch.002"
    #Node properties
    Switch_002.input_type = "VECTOR"
    #unlinked node I/O
    Switch_002.inputs[1].default_value = False
    Switch_002.inputs[2].default_value = 0.0
    Switch_002.inputs[3].default_value = 0.0
    Switch_002.inputs[4].default_value = 0
    Switch_002.inputs[5].default_value = 0
    Switch_002.inputs[6].default_value = False
    Switch_002.inputs[7].default_value = True
    Switch_002.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_002.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_002.inputs[12].default_value = ""
    Switch_002.inputs[13].default_value = ""
    Switch_002.inputs[16].default_value = None
    Switch_002.inputs[17].default_value = None
    Switch_002.inputs[18].default_value = None
    Switch_002.inputs[19].default_value = None
    Switch_002.inputs[20].default_value = None
    Switch_002.inputs[21].default_value = None
    Switch_002.inputs[22].default_value = None
    Switch_002.inputs[23].default_value = None
    Switch_002.inputs[24].default_value = None
    Switch_002.inputs[25].default_value = None

    Vector_Math_008 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_008.location = [2107, 1046]
    Vector_Math_008.name = "Vector Math.008"
    #Node properties
    Vector_Math_008.operation = "NORMALIZE"
    #unlinked node I/O
    Vector_Math_008.inputs[1].default_value = (2.0, 2.0, 2.0)
    Vector_Math_008.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_008.inputs[3].default_value = 1.0

    Vector_Math_006 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_006.location = [1335, 1140]
    Vector_Math_006.name = "Vector Math.006"
    #Node properties
    Vector_Math_006.operation = "ADD"
    #unlinked node I/O
    Vector_Math_006.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_006.inputs[3].default_value = 1.0

    Switch_005 = radial_array.nodes.new("GeometryNodeSwitch")
    Switch_005.location = [1839, 1261]
    Switch_005.name = "Switch.005"
    #Node properties
    Switch_005.input_type = "VECTOR"
    #unlinked node I/O
    Switch_005.inputs[1].default_value = False
    Switch_005.inputs[2].default_value = 0.0
    Switch_005.inputs[3].default_value = 0.0
    Switch_005.inputs[4].default_value = 0
    Switch_005.inputs[5].default_value = 0
    Switch_005.inputs[6].default_value = False
    Switch_005.inputs[7].default_value = True
    Switch_005.inputs[8].default_value = (0.0, 0.0, 0.0)
    Switch_005.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_005.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    Switch_005.inputs[12].default_value = ""
    Switch_005.inputs[13].default_value = ""
    Switch_005.inputs[16].default_value = None
    Switch_005.inputs[17].default_value = None
    Switch_005.inputs[18].default_value = None
    Switch_005.inputs[19].default_value = None
    Switch_005.inputs[20].default_value = None
    Switch_005.inputs[21].default_value = None
    Switch_005.inputs[22].default_value = None
    Switch_005.inputs[23].default_value = None
    Switch_005.inputs[24].default_value = None
    Switch_005.inputs[25].default_value = None

    Vector_Math_014 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_014.location = [1505, 1012]
    Vector_Math_014.name = "Vector Math.014"
    #Node properties
    Vector_Math_014.operation = "LENGTH"
    #unlinked node I/O
    Vector_Math_014.inputs[1].default_value = (2.0, 2.0, 2.0)
    Vector_Math_014.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_014.inputs[3].default_value = 1.0

    Math_005 = radial_array.nodes.new("ShaderNodeMath")
    Math_005.location = [1676, 1046]
    Math_005.name = "Math.005"
    #Node properties
    Math_005.operation = "GREATER_THAN"
    Math_005.use_clamp = False
    #unlinked node I/O
    Math_005.inputs[1].default_value = 9.999999747378752e-06
    Math_005.inputs[2].default_value = 0.5

    Vector_Math = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math.location = [-1583, 586]
    Vector_Math.name = "Vector Math"
    #Node properties
    Vector_Math.operation = "ADD"
    #unlinked node I/O
    Vector_Math.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math.inputs[3].default_value = 1.0

    Math_006 = radial_array.nodes.new("ShaderNodeMath")
    Math_006.location = [-1070, 952]
    Math_006.name = "Math.006"
    #Node properties
    Math_006.operation = "SIGN"
    Math_006.use_clamp = False
    #unlinked node I/O
    Math_006.inputs[1].default_value = 0.5
    Math_006.inputs[2].default_value = 0.5

    Vector_Math_010 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_010.location = [-1248, 907]
    Vector_Math_010.name = "Vector Math.010"
    #Node properties
    Vector_Math_010.operation = "DOT_PRODUCT"
    #unlinked node I/O
    Vector_Math_010.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_010.inputs[3].default_value = 1.0

    Vector_Math_001 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_001.location = [-1408, 648]
    Vector_Math_001.name = "Vector Math.001"
    #Node properties
    Vector_Math_001.operation = "DIVIDE"
    #unlinked node I/O
    Vector_Math_001.inputs[1].default_value = (2.0, 2.0, 2.0)
    Vector_Math_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    Vector_Math_001.inputs[3].default_value = 1.0

    Vector_Math_015 = radial_array.nodes.new("ShaderNodeVectorMath")
    Vector_Math_015.location = [-954, 735]
    Vector_Math_015.name = "Vector Math.015"
    #Node properties
    Vector_Math_015.operation = "SCALE"
    #unlinked node I/O
    Vector_Math_015.inputs[1].default_value = (2.0, 2.0, 2.0)
    Vector_Math_015.inputs[2].default_value = (0.0, 0.0, 0.0)
    #group llinks
    radial_array.links.new(Realize_Instances.outputs["Geometry"], Group_Output.inputs[0])
    radial_array.links.new(Group_Input.outputs[0], Bounding_Box.inputs["Geometry"])
    radial_array.links.new(Bounding_Box.outputs["Min"], Vector_Math.inputs[0])
    radial_array.links.new(Bounding_Box.outputs["Max"], Vector_Math.inputs[1])
    radial_array.links.new(Vector_Math.outputs[0], Vector_Math_001.inputs[0])
    radial_array.links.new(Duplicate_Elements.outputs["Geometry"], Translate_Instances.inputs["Instances"])
    radial_array.links.new(Scale_Instances_001.outputs["Instances"], Duplicate_Elements.inputs["Geometry"])
    radial_array.links.new(Translate_Instances.outputs["Instances"], Rotate_Instances.inputs["Instances"])
    radial_array.links.new(Math_001.outputs[0], Math.inputs[0])
    radial_array.links.new(Rotate_Euler.outputs["Rotation"], Rotate_Instances.inputs["Rotation"])
    radial_array.links.new(Math.outputs[0], Rotate_Euler.inputs["Angle"])
    radial_array.links.new(Vector_Rotate_001.outputs["Vector"], Rotate_Euler.inputs["Axis"])
    radial_array.links.new(Duplicate_Elements.outputs["Duplicate Index"], Math.inputs[1])
    radial_array.links.new(Math_002.outputs[0], Math_001.inputs[0])
    radial_array.links.new(Group_Input.outputs[1], Duplicate_Elements.inputs["Amount"])
    radial_array.links.new(Rotate_Instances.outputs["Instances"], Scale_Instances.inputs["Instances"])
    radial_array.links.new(Vector_Math_002.outputs[0], Scale_Instances.inputs["Scale"])
    radial_array.links.new(Switch.outputs[3], Vector_Math_002.inputs[1])
    radial_array.links.new(Group_Input.outputs[3], Math_002.inputs[0])
    radial_array.links.new(Group_Input.outputs[10], Object_Info.inputs["Object"])
    radial_array.links.new(Geometry_to_Instance.outputs["Instances"], Scale_Instances_001.inputs["Instances"])
    radial_array.links.new(Switch.outputs[3], Scale_Instances_001.inputs["Scale"])
    radial_array.links.new(Group_Input.outputs[5], Switch.inputs[0])
    radial_array.links.new(Object_Info.outputs["Scale"], Switch.inputs[9])
    radial_array.links.new(Switch.outputs[3], Vector_Math_003.inputs[1])
    radial_array.links.new(Switch_003.outputs[3], Translate_Instances.inputs["Translation"])
    radial_array.links.new(Vector_Math_012.outputs[0], Rotate_Instances.inputs["Pivot Point"])
    radial_array.links.new(Group_Input.outputs[6], Switch_001.inputs[0])
    radial_array.links.new(Vector_Math_003.outputs[0], Switch_001.inputs[9])
    radial_array.links.new(Vector.outputs["Vector"], Vector_Rotate.inputs["Vector"])
    radial_array.links.new(Align_Euler_to_Vector.outputs["Rotation"], Vector_Rotate.inputs["Rotation"])
    radial_array.links.new(Vector_Rotate.outputs["Vector"], Vector_Math_005.inputs[0])
    radial_array.links.new(Group_Input.outputs[4], Vector_Math_005.inputs[3])
    radial_array.links.new(Vector_Rotate_001.outputs["Vector"], Align_Euler_to_Vector.inputs["Vector"])
    radial_array.links.new(Vector_Rotate_001.outputs["Vector"], Vector_Math_007.inputs[0])
    radial_array.links.new(Math_003.outputs[0], Vector_Math_007.inputs[3])
    radial_array.links.new(Group_Input.outputs[6], Switch_002.inputs[0])
    radial_array.links.new(Vector_Math_008.outputs[0], Vector_Math_009.inputs[0])
    radial_array.links.new(Group_Input.outputs[4], Vector_Math_009.inputs[3])
    radial_array.links.new(Vector_Math_009.outputs[0], Switch_002.inputs[8])
    radial_array.links.new(Group_Input.outputs[6], Switch_001.inputs[8])
    radial_array.links.new(Vector_Math_005.outputs[0], Switch_002.inputs[9])
    radial_array.links.new(Switch_002.outputs[3], Switch_003.inputs[9])
    radial_array.links.new(Vector_Math_005.outputs[0], Switch_003.inputs[8])
    radial_array.links.new(Group_Input.outputs[0], Geometry_to_Instance.inputs["Geometry"])
    radial_array.links.new(Vector_Math_007.outputs[0], Vector_Math_006.inputs[0])
    radial_array.links.new(Vector_Math_004.outputs[1], Math_003.inputs[0])
    radial_array.links.new(Vector_Rotate_001.outputs["Vector"], Vector_Math_004.inputs[1])
    radial_array.links.new(Group_Input.outputs[2], Vector_Math_011.inputs[0])
    radial_array.links.new(Group_Input.outputs[7], Switch_004.inputs[0])
    radial_array.links.new(Switch_004.outputs[1], Math_001.inputs[1])
    radial_array.links.new(Group_Input.outputs[1], Switch_004.inputs[5])
    radial_array.links.new(Group_Input.outputs[1], Math_004.inputs[0])
    radial_array.links.new(Math_004.outputs[0], Switch_004.inputs[4])
    radial_array.links.new(Switch_009.outputs[3], Vector_Math_012.inputs[1])
    radial_array.links.new(Switch_001.outputs[3], Vector_Math_012.inputs[0])
    radial_array.links.new(Switch_006.outputs[3], Vector_Math_004.inputs[0])
    radial_array.links.new(Vector_Math_003.outputs[0], Vector_Math_013.inputs[0])
    radial_array.links.new(Switch_006.outputs[3], Vector_Math_006.inputs[1])
    radial_array.links.new(Scale_Instances.outputs["Instances"], Realize_Instances.inputs["Geometry"])
    radial_array.links.new(Vector_Math_011.outputs[0], Vector_Rotate_001.inputs["Vector"])
    radial_array.links.new(Group_Input.outputs[9], Vector_Rotate_001.inputs["Rotation"])
    radial_array.links.new(Switch_009.outputs[3], Vector_Math_013.inputs[1])
    radial_array.links.new(Group_Input.outputs[6], Switch_006.inputs[0])
    radial_array.links.new(Vector_Math_013.outputs[0], Switch_006.inputs[8])
    radial_array.links.new(Vector_Math_003.outputs[0], Switch_006.inputs[9])
    radial_array.links.new(Group_Input.outputs[8], Switch_009.inputs[8])
    radial_array.links.new(Group_Input.outputs[6], Switch_009.inputs[0])
    radial_array.links.new(Vector_Math_014.outputs[1], Math_005.inputs[0])
    radial_array.links.new(Math_005.outputs[0], Switch_005.inputs[0])
    radial_array.links.new(Vector_Math_015.outputs[0], Vector_Math_003.inputs[0])
    radial_array.links.new(Vector_Math_006.outputs[0], Vector_Math_014.inputs[0])
    radial_array.links.new(Switch_005.outputs[3], Vector_Math_008.inputs[0])
    radial_array.links.new(Vector_Math_006.outputs[0], Switch_005.inputs[9])
    radial_array.links.new(Math_005.outputs[0], Switch_003.inputs[0])
    radial_array.links.new(Vector_Math_001.outputs[0], Vector_Math_010.inputs[1])
    radial_array.links.new(Bounding_Box.outputs["Max"], Vector_Math_010.inputs[0])
    radial_array.links.new(Vector_Math_010.outputs[1], Math_006.inputs[0])
    radial_array.links.new(Vector_Math_001.outputs[0], Vector_Math_015.inputs[0])
    radial_array.links.new(Math_006.outputs[0], Vector_Math_015.inputs[3])
    Group_Input.outputs[0].name = "Geometry"
    radial_array.inputs[0].name = "Geometry"
    Group_Input.outputs[1].name = "Count"
    radial_array.inputs[1].name = "Count"
    Group_Input.outputs[2].name = "Axis"
    radial_array.inputs[2].name = "Axis"
    Group_Input.outputs[3].name = "Rotation"
    radial_array.inputs[3].name = "Rotation"
    Group_Input.outputs[4].name = "Offset"
    radial_array.inputs[4].name = "Offset"
    Group_Input.outputs[5].name = "Apply Scale"
    radial_array.inputs[5].name = "Apply Scale"
    Group_Input.outputs[6].name = "Center Pivot"
    radial_array.inputs[6].name = "Center Pivot"
    Group_Input.outputs[7].name = "Full Circle"
    radial_array.inputs[7].name = "Full Circle"
    Group_Input.outputs[8].name = "Pivot Offset"
    radial_array.inputs[8].name = "Pivot Offset"
    Group_Input.outputs[9].name = "Rotation Offset"
    radial_array.inputs[9].name = "Rotation Offset"
    Group_Input.outputs[10].name = "Self"
    radial_array.inputs[10].name = "Self"
    Group_Output.inputs[0].name = "Geometry"
    radial_array.outputs[0].name = "Geometry"
    radial_array.inputs["Count"].min_value = 1
    radial_array.inputs["Count"].max_value = 2147483647
    radial_array.inputs["Axis"].min_value = 0.0
    radial_array.inputs["Axis"].max_value = 1.0
    radial_array.inputs["Rotation"].min_value = 0.0
    radial_array.inputs["Rotation"].max_value = 360.0
    radial_array.inputs["Offset"].min_value = -10000.0
    radial_array.inputs["Offset"].max_value = 10000.0
    radial_array.inputs["Pivot Offset"].min_value = -3.4028234663852886e+38
    radial_array.inputs["Pivot Offset"].max_value = 3.4028234663852886e+38
    radial_array.inputs["Rotation Offset"].min_value = -3.4028234663852886e+38
    radial_array.inputs["Rotation Offset"].max_value = 3.4028234663852886e+38
    radial_array.inputs["Count"].default_value = 1
    radial_array.inputs["Axis"].default_value = [0.0, 0.0, 1.0]
    radial_array.inputs["Rotation"].default_value = 0.0
    radial_array.inputs["Offset"].default_value = 0.0
    radial_array.inputs["Apply Scale"].default_value = False
    radial_array.inputs["Center Pivot"].default_value = False
    radial_array.inputs["Full Circle"].default_value = False
    radial_array.inputs["Pivot Offset"].default_value = [0.0, 0.0, 0.0]
    radial_array.inputs["Rotation Offset"].default_value = [0.0, 0.0, 0.0]
