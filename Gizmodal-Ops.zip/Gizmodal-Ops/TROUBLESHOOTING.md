# Known issues and limitations and how to resolve them.

## I've switched my Keymap and now Gizmodal Ops doesn't work
Since Gizmodal Ops modifies the active Keymap in order to work, you need to restart Blender after enabling another Keymap. Gizmodal Ops should now work with your new Keymap.

## My settings are reset after closing Blender
If Auto-Save Preferences is disabled, you need to go to Edit > Preferences > Save Preferences to make sure that your addon settings are saved.