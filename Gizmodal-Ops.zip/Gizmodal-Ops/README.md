# Gizmodal-Ops
<!-- Video demo here -->
The moment you start using Gizmodal Ops you’ll never want to go back to standard Blender ever again. This is a more **intuitive** way of working that you need to experience to understand. It seamlessly blends two workflows already in Blender into one harmonious workflow.

**For Blender 2.83 and above.**

Features:
- **Reveals/Hides** the gizmo during modal operations.
- Makes working in Blender much **easier** & more **intuitive**.
- **Indispensable** for teachers.
