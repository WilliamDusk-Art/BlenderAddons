# Changelog

## Version 1.0.1 - 2023-12-19

### Fixes

- Fix: Gizmodal Ops doesn't work for Blender 4.0 ([#12](https://github.com/BlenderDefender/Gizmodal-Ops/issues/12))
- Fix: Error Messages are displayed when disabling Gizmodal Ops with a custom keymap ([#6](https://github.com/BlenderDefender/Gizmodal-Ops/issues/6))

---

## Version 1.0.0 - 2022-06-23

Initial release

### Features

- Access Gizmo and modal operations with **one shortcut.**
