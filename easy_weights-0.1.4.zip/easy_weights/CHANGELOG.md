## 0.1.4 - 2023-10-31 
 
### FIXED 
- Fix a crash in hotkeys.py

### REMOVED 
- Remove hotkeys for painting.

### UN-CATEGORIZED 
- Upgrade to Blender 4.0
- EasyWeight console warnings & more
- Catch an error (not sure of cause yet)
- Update hotkey registration code
- Use consistent registration pattern

## 0.1.2 - 2023-08-02 
 
### FIXED 
- Fix Changelog Rendering (#125)
- Fix Addon Install Instructions

## 0.1.1 - 2023-06-02 
 
## DOCUMENTED
- Initial release
