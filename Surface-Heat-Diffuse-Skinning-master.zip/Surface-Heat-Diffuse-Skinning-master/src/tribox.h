//
//  tribox.h
//  VoxelHeatDiffuse
//
//  Created by MINGFENWANG on 2017/10/7.
//  Copyright © 2017年 MINGFENWANG. All rights reserved.
//

#ifndef tribox_h
#define tribox_h

int triBoxOverlap(float boxcenter[3],float boxhalfsize[3],float triverts[3][3]);

#endif /* tribox_h */
